export fDSS14PATH=`pwd`



