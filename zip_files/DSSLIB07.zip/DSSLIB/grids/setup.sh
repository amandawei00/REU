export fDSSPATH=`pwd`



